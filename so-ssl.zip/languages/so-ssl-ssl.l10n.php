<?php
return [ 'project-id-version'        => 'So SSL',
         'report-msgid-bugs-to'      => '',
         'pot-creation-date'         => '2025-04-25 17:37+0000',
         'po-revision-date'          => '2025-05-19 20:13+0000',
         'last-translator'           => 'FULL NAME <EMAIL@ADDRESS>',
         'language-team'             => 'ssl',
         'language'                  => 'ssl',
         'plural-forms'              => 'nplurals=2; plural=n != 1;',
         'mime-version'              => '1.0',
         'content-type'              => 'text/plain; charset=UTF-8',
         'content-transfer-encoding' => '8bit',
         'x-generator'               => 'Loco https://localise.biz/',
         'x-loco-version'            => '2.7.2; wp-6.8',
         'x-domain'                  => 'so-ssl',
         'messages'                  => []
];
